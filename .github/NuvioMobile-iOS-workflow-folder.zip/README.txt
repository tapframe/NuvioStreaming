NuvioMobile-iOS workflow folder

This ZIP contains:

.github/workflows/main.yml

This workflow includes:
- broken recursive submodule bypass
- MPVKit manual clone
- simulator-only build
- Apple signing/profile bypass
- one-line xcodebuild command to avoid the "-project: command not found" issue

Upload the .github folder to the root of your GitHub repo.
